package algstudent.s3;

public class CalendarTimes {
	
	public static void main(String args[]) {
		long t1, t2;
		String[] dummy;
		for (int i = 2; i < 1000000; i*=2) {
			dummy = new String[i];
			for (int j = 0; j < i; j++) {
				dummy[j] = "Player " + j;
			}
			t1 = System.currentTimeMillis();
			for (int rep = 0; rep < 1; rep++) {
				Calendar.pairing(dummy);
			}
			t2 = System.currentTimeMillis();
			System.out.println("For a size of " + i + ", it takes " + (t2-t1) + " milliseconds");
		}
	}
	
}
