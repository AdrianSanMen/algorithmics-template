package algstudent.s3;

public class Calendar {
	
	public static void main (String args []) 
	{
		String[] names = new String [args.length-1];
		for (int i = 1; i < args.length; i++) {
			names[i-1] = args[i];
		}
		String[][] pairs = pairing(names);
		
		System.out.print("PLAYER/OPPONENT\t");
		for (int i = 1; i < pairs.length; i++) {
			System.out.print("DAY " + i + "\t");
		}
		System.out.println();
		for (int i = 0; i < pairs.length; i++) {
			System.out.print("\t");
			for (int j = 0; j < pairs.length; j++) {
				System.out.print(pairs[i][j] + "\t");
			}
			System.out.println();
		}
		 
	}

	
	/**
	 * Takes a group of people and pairs them so anyone of them faces everyone of them without repeating opponent
	 * @param people Array containing the names of the people to pair
	 * @return First column: participants, rest of them, pairs for each day
	 */
	public static String[][] pairing(String[] people){
		String[][] pairs = new String[people.length][people.length];
		if (people.length == 2) {	// O(1)
			pairs[0][0] = people[0];
			pairs[0][1] = people[1];
			pairs[1][0] = people[1];
			pairs[1][1] = people[0];
		}
		else {	// O(n^2)
			String[] foo = new String[people.length/2];
			String[] bar = new String[people.length/2];
			for (int i = 0; i < people.length/2; i++) {
				foo[i] = people[i];
				bar[i] = people[i+people.length/2];
			}
			String[][] firstQuad = pairing(foo);
			String[][] secondQuad = pairing(bar);
			for (int i = 0; i <people.length/2; i++) {
				for (int j = 0; j <people.length/2; j++) {
					pairs[i][j] = firstQuad[i][j];
					pairs[i][j+people.length/2] = secondQuad[i][j];
					pairs[i+people.length/2][j] = secondQuad[i][j];
					pairs[i+people.length/2][j+people.length/2] = firstQuad[i][j];
				}
			}
		}
		return pairs;
	}
}
