package algstudent.s4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GraphColouring {
	
//	private final static int MAXIMUM_EDGES = 8;

	enum Colors {
		RED ("red"),
		BLUE ("blue"),
		GREEN("green"),
		YELLOW("yellow"),
		ORANGE("orange"),
		PURPLE("purple"),
		CYAN("cyan"),
		MAGENTA("magenta"),
		LIME("lime");
		
		public final String label;
		
		private Colors(String label) {
			this.label = label;
		}
	}
	
	public static Map<String, String> greedy(Map<String, List<String>> graph) {
		Map<String, String> solution = new HashMap<String, String>();
//		Map<String, List<String>> ordered = new HashMap<String, List<String>>();
//		
//		for(int i = MAXIMUM_EDGES; i >= 0; i--) {
//			for(Map.Entry<String, List<String>> pair: graph.entrySet()) {
//				if(pair.getValue().size() == i) {
//					ordered.put(pair.getKey(), pair.getValue());
//				}
//			}
//		}
		
		
		// Iterating over the map
		for(Map.Entry<String, List<String>> pair: graph.entrySet()) {
			List<String> neighbours = new ArrayList<String>();
			for (Object neighbour: pair.getValue()) {
				neighbours.add(String.valueOf(neighbour));
			}
			// Iterating over the colors
			for(Colors color: Colors.values()) {
				int count = 0;
				// Iterating over the values of the map
				for (String neighbour: neighbours) {
					// If the node is painted and has the color --> Skip color
					if (solution.get(neighbour) != null && solution.get(neighbour).equals(color.label)) {
						break;
					}
					else {
						count++;
						
					}
				}
				// If none of the nodes have the color --> Paint it
				if (count == pair.getValue().size()) {
					solution.put(pair.getKey(), color.label);
					break;
				}
			}
		}
		return solution;
	}
	

}
