package algstudent.s4;

public class GreedyTimes {

	public static void main(String args[]) {
		long t1, t2;
		for (int i = 8; i < 100000; i*=2) {
			t1 = System.currentTimeMillis();
			for (int rep = 0; rep < 100; rep++) {
				Greedy.main(i);
			}
			t2 = System.currentTimeMillis();
			System.out.println("For graph of " + i + " nodes, it takes " + (t2-t1) + " milliseconds");
		}
	}
	
}
