package algstudent.s6;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class NullPath {
	
	private final static int MIN_WEIGHT = 10;
	private final static int MAX_WEIGHT = 99;

	private static int size;
	private static int[][] weights;
	private static boolean traversed[];
	private static int cost;
	private static List<Integer> path;
	private static boolean found;
	
	private static void generateGraph(int numNodes) {
		size = numNodes;
		weights = new int[size][size];
		traversed = new boolean[size];
		cost = 0;
		path = new ArrayList<Integer>();
		found = false;
		
		Random random = new Random();
		
		for (int row = 0; row < size; row++) {
			traversed[row] = false;
			for (int col = 0; col < size; col++) {
				
				if (random.nextInt(2) % 2 == 0) {
					weights[row][col] = random.nextInt(MAX_WEIGHT + 1 - MIN_WEIGHT) + MIN_WEIGHT;
				}
				else {
					weights[row][col] = -random.nextInt(MAX_WEIGHT + 1 - MIN_WEIGHT) + MIN_WEIGHT;
				}
				
			}
		}
	}
	
	public static void getNullPath(int numNodes) {
		generateGraph(numNodes);
		int origin = 0;
		int target = numNodes - 1;
		traversed[origin] = true;
		traversed[target] = true;	// Avoid iterations where this node is used as a pivot
		int mark = origin;
		path.add(origin);
		backtracking(mark, target);
		if (!found) {
			System.out.println("Solution not found");
		}
	}
	
	private static void backtracking(int mark, int target) {
		if (path.size() == size-1) {	// && -99 <= cost && cost <= 99) {
			cost += weights[mark][target];
			if (-99 <= cost && cost <= 99) {
				found = true;
				System.out.println("Solution found for size " + size + " with cost " + cost);
//				for (Integer node: path) {
//					System.out.print(node + " -> ");
//				}
//				System.out.print(target);
//				System.out.println();
				return;
			}
			else {
				cost -= weights[mark][target];
				return;
			}
		}
		
		// Pruning
			int prune = cost / (size - 1 - path.size());
			if (prune > MAX_WEIGHT || prune <  -MAX_WEIGHT) {
				return;
		}
		
		
		
		// Traversing through the tree of states
		for (int node = 0; node < size; node++) {
			if (traversed[node]) {
				continue;
			}
			// Update the new path
			cost += weights[mark][node];
			traversed[node] = true;
			path.add(node);
			
			// Try the new path
			backtracking(node, target);
			if (found) {	// Comment line to get all solutions
				return;
			}
			
			// Go back to a previous state
			cost -= weights[mark][node];
			traversed[node] = false;
			path.remove(path.indexOf(node));
			
		}
	}
}
