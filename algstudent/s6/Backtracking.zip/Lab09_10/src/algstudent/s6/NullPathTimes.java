package algstudent.s6;

public class NullPathTimes {
	
	private static int reps = 100;
	
	public static void main(String[] args) {
		long t1, t2;
		for (int i = 20; i < 45; i+=5) {
			t1 = System.currentTimeMillis();
			for (int rep = 0; rep < reps; rep++) {
				System.out.println("------------------------");
				System.out.println("Repetition: " + rep);
				NullPath.getNullPath(i);
			}
			t2 = System.currentTimeMillis();
			System.out.println("For graph of " + i + " nodes, it takes " + (t2-t1)/100.0 + " milliseconds");
		}
	}
}
