package algstudent.s5;

public class MinimumPathsTimes {
	public static void main(String args[]) {
		long t1, t2;
		for (int i = 200; i < 10000; i*=2) {
			t1 = System.currentTimeMillis();
			for (int rep = 0; rep < 1; rep++) {
				MinimumPaths.floyd(i);
			}
			t2 = System.currentTimeMillis();
			System.out.println("For graph of " + i + " nodes, it takes " + (t2-t1) + " milliseconds");
		}
	}
}
