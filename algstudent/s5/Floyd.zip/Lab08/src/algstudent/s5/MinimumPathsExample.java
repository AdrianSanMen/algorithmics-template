package algstudent.s5;

//MINIMUM PATHS IN A GRAPH BY FLOYD-WARSHALL
//IT IS A SOLUTION BY DYNAMIC PROGRAMMING
//ITS TIME COMPLEXITY IS CUBIC O(n^3)
public class MinimumPathsExample {
	static String[] v; //node vector
	static int[][] weights; //weight matrix
	static int[][] costs; //Floyd's paths cost matrix
	static int[][] p; //predecessor matrix (steps) in Floyd paths
	
	private static final int EMPTY = -1;

	public static void main(String arg[]) {
		int n = 5; //nodes of example graph
		v = new String[n];
		for (int i = 0; i < n; i++)
			v[i] = "NODE" + i;

		weights = new int[n][n];
		costs = new int[n][n];
		p = new int[n][n];

		fillInWeights(weights); //weights for the example
		System.out.println("WEIGHT MATRIX IS:");
		printMatrix(weights);

		floyd();

		System.out.println("MINIMUM COST MATRIX IS:");
		printMatrix(costs);

		System.out.println("P MATRIX IS:");
		printMatrix(p);

		System.out.println();
		System.out.println("MINIMUM PATHS IN THE EXAMPLE GRAPH (for every pair of different nodes):");
		System.out.println();
		for (int source = 0; source <= n-1; source++)
			for (int target = 0; target <= n-1; target++)
				if (source != target) {
					System.out.print("FROM " + v[source] + " TO " + v[target] + " = ");
					minimumPath(source, target);
					if (costs[source][target] < 10000000)
						System.out.println("MINIMUM COST=" + costs[source][target]);
					System.out.println("**************");
				}

	}

	/* ITERATIVE WITH CUBIC COMPLEXITY O(n^3) */
	static void floyd() {
		int n = weights.length;
		copyWeights();
		for (int pivot = 0; pivot < n; pivot++) {
			for (int origin = 0; origin < n; origin++) {
				for (int target = 0; target < n; target++) {
					if (origin == target) {
						continue;
					}
					if (costs[origin][target] > costs[origin][pivot] + costs[pivot][target]) {
						costs[origin][target] = costs[origin][pivot] + costs[pivot][target];
						p[origin][target] = pivot;
					}	
				}
			}
		}
	}
	
	private static void copyWeights(){
		int n = weights.length;
		for (int row = 0; row < n; row++) {
			for (int col = 0; col < n; col++) {
				p[row][col] = EMPTY;
				costs[row][col] = weights[row][col];
			}
		}
	}

	static void minimumPath(int source, int target) {
		StringBuilder dummy = new StringBuilder();
		if(costs[source][target] < 1000000) {
			dummy.append(v[source]);
			dummy.append("-->");
			if (p[source][target] != EMPTY) {
				dummy.append(path(source, p[source][target], target));
			}
			dummy.append(v[target]);
		} else {
			dummy.append("THERE IS NO PATH");
		}
			
		
		System.out.println(dummy.toString());
	}

	/* IT IS RECURSIVE and WORST CASE is O(n), IT IS O(n) if you write all nodes */
	static String path(int source, int pivot, int target) {
		StringBuilder dummy = new StringBuilder();
		dummy.append(v[pivot]);
		dummy.append("-->");
		
		if (p[source][pivot] == EMPTY && p[pivot][target] == EMPTY) {
			return dummy.toString();
		}
		
		else if (p[source][pivot] == EMPTY) {
			return dummy.toString() + path(pivot, p[pivot][target], target);
		}
		
		else if (p[pivot][target] == EMPTY) {
			return path(source, p[source][pivot], pivot) + dummy.toString();
		}
		
		else {
			return path(source, p[source][pivot], pivot) + dummy.toString() + path(pivot, p[pivot][target], target);
		}
	}

	/* load the example cost matrix */
	static void fillInWeights(int[][] w) {
		for (int i = 0; i < w.length; i++)
			for (int j = 0; j < w.length; j++)
				w[i][j] = 10000000;
		w[0][1] = 19;
		w[0][2]=  10;
		w[1][2]=  20;
		w[2][1] = 19;
		w[2][3] = 14;
		w[3][0] = 27;
		w[3][1] = 67;
	    w[3][2]=  21;
		w[4][1]=  80;
	}
	
	/* print the cost matrix */
	static void printMatrix(int[][] a) {
		int n = a.length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				System.out.print(String.format("%10s", a[i][j]));
			System.out.println();
		}
		System.out.println();
	}

}