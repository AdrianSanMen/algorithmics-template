package algstudent.s5;

import java.util.Random;

public class MinimumPaths {

	private static final int EMPTY = -1;
	private static final int INFINITE = Integer.MAX_VALUE;
	private static final int MIN_WEIGHT = 10;
	private static final int MAX_WEIGHT = 99;
//	private static final double p1 = 0.5;
	
	private static String[] nodes;
	private static boolean[][] edges;	// Edge matrix
	private static int[][] weights;	// Weight matrix
	private static int size;
	private static int[][] A;	// Minimum cost to go from row to column
	private static int[][] P;	// Pivot needed to get from row to column in minimal cost
	
	
	private static void generateGraph(int numNodes) {
		size = numNodes;
		nodes = new String[size];
		edges = new boolean[size][size];
		weights = new int[size][size];
		A = new int[size][size];
		P = new int[size][size];
		Random random = new Random();
		for (int row = 0; row < size; row++) {
			// Generate node
			nodes[row] = "NODE" + row;
			for (int col = 0; col < size; col++) {
				// No loops
				if(row != col) {
					// Chance to generate edge
					if(random.nextInt(2) % 2 == 0) {	// Update for p1
						edges[row][col] = true;
						weights[row][col] = random.nextInt(MAX_WEIGHT + 1 - MIN_WEIGHT) + MIN_WEIGHT;
					}
				}
				else {
					edges[row][col] = false;
					weights[row][col] = EMPTY;
				}
			}
		}
	}
	
	/*
	 * Initialize Floyd method, P to empty and A to the adjacency matrix with weights
	 */
	private static void initsFloyd(){
		for (int row = 0; row < size; row++) {
			for (int col = 0; col < size; col++) {
				P[row][col] = EMPTY;
				if (edges[row][col]) {
					A[row][col] = weights[row][col];
				}
				else if(row == col){
					A[row][col] = 0;
				}
				else {
					A[row][col] = INFINITE;
				}
			}
		}
	}
	
	/**
	 * Executes the Floyd method to contruct the A and P matrices
	 */
	public static void floyd(int nodes) {
		generateGraph(nodes);
		initsFloyd();
		for (int pivot = 0; pivot < size; pivot++) {
			for (int origin = 0; origin < size; origin++) {
				for (int target = 0; target < size; target++) {
					if (origin == target) {
						continue;
					}
					if (A[origin][target] > A[origin][pivot] + A[pivot][target]) {
						A[origin][target] = A[origin][pivot] + A[pivot][target];
						P[origin][target] = pivot;
					}	
				}
			}
		}
	}
	
	public static void printPath() {
		for (int origin = 0; origin < size; origin++) {
			for (int target = 0; target < size; target++) {
				StringBuilder dummy = new StringBuilder();
				dummy.append("FROM ");
				dummy.append(nodes[origin]);
				dummy.append(" TO ");
				dummy.append(nodes[target]);
				dummy.append(" = ");
				dummy.append(nodes[origin]);
				dummy.append("-->");
				if (P[origin][target] != EMPTY) {
					dummy.append(getPath(origin, P[origin][target], target));
				}
				dummy.append(nodes[target]);
				
				System.out.println(dummy.toString());
				System.out.println("MINIMUM COST = " + A[origin][target]);
				System.out.println("**************");
			}
		}
		
	}
	
	private static String getPath(int origin, int pivot, int target) {
		StringBuilder dummy = new StringBuilder();
		dummy.append(nodes[pivot]);
		dummy.append("-->");
		
		if (P[origin][pivot] == EMPTY && P[pivot][target] == EMPTY) {
			return dummy.toString();
		}
		
		else if (P[origin][pivot] == EMPTY) {
			return dummy.toString() + getPath(pivot, P[pivot][target], target);
		}
		
		else if (P[pivot][target] == EMPTY) {
			return getPath(origin, P[origin][pivot], pivot) + dummy.toString();
		}
		
		else {
			return getPath(origin, P[origin][pivot], pivot) + dummy.toString() + getPath(pivot, P[pivot][target], target);
		}

	}
}
