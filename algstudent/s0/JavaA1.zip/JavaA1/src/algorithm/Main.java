package algorithm;

import java.util.ArrayList;


public class Main {

	public static void main(String[] args) {
		Algorithm dummy = new Algorithm();
		
		
		for (int i = 10000; i <= 640000; i*=2) {
			long initTime =  System.currentTimeMillis();
			ArrayList<Integer> primes = dummy.primeList(i);
			long finalTime = System.currentTimeMillis();
			
			System.out.println(finalTime - initTime);
		}

	}

}
