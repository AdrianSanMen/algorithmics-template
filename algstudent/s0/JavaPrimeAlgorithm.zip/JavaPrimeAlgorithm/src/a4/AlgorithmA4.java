package a4;

import java.util.ArrayList;

public class AlgorithmA4 {

	public AlgorithmA4() {
		
	}
	
	
	public boolean primeA4(int m) {
		
		for (int i = 2; i < Math.sqrt(m) + 1; i++) {
			if(m%i == 0) {
				return false;
			}
		}
		return true;
		
	}
	
	
	
	public ArrayList<Integer> primeList(int n) {
		ArrayList<Integer> primes = new ArrayList<Integer>();
		
		for (int i = 2; i <= n; i++) {
			if (primeA4(i)) {
				primes.add(i);
			}
		}
		
		return primes;
	}
	
}
