package a4;

import java.util.ArrayList;

public class MainA4 {

	public static void main(String[] args) {
		
		AlgorithmA4 dummy = new AlgorithmA4();
		
		for (int i = 10000; i <= 640000; i*=2) {
			long initTime =  System.currentTimeMillis();
			ArrayList<Integer> primes = dummy.primeList(i);
			long finalTime = System.currentTimeMillis();
			
			System.out.println(finalTime - initTime);
		}
		
	}
}
