package a2;

import java.util.ArrayList;

public class AlgorithmA2 {

	public AlgorithmA2() {
		
	}
	
	
	public boolean primeA2(int m) {
		
		for (int i = 2; i < m; i++) {
			if(m%i == 0) {
				return false;
			}
		}
		return true;
		
	}
	
	
	
	public ArrayList<Integer> primeList(int n) {
		ArrayList<Integer> primes = new ArrayList<Integer>();
		
		for (int i = 2; i <= n; i++) {
			if (primeA2(i)) {
				primes.add(i);
			}
		}
		
		return primes;
	}
}
