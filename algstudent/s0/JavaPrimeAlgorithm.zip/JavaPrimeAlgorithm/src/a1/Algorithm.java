package a1;

import java.util.ArrayList;

public class Algorithm {

	
	public Algorithm() {
		
	}
	
	
	public boolean primeA1(int m) {
		boolean p = true;
		
		for (int i = 2; i < m; i++) {
			if(m%i == 0) {
				p = false;
			}
		}
		return p;
		
	}
	
	
	
	public ArrayList<Integer> primeList(int n) {
		ArrayList<Integer> primes = new ArrayList<Integer>();
		
		for (int i = 2; i <= n; i++) {
			if (primeA1(i)) {
				primes.add(i);
			}
		}
		
		return primes;
	}
}
