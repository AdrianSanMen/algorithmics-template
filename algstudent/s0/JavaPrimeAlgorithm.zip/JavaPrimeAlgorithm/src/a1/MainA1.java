package a1;

import java.util.ArrayList;

public class MainA1 {

	public static void main(String[] args) {

		AlgorithmA1 dummy = new AlgorithmA1();
		
		
		for (int i = 10000; i <= 640000; i*=2) {
			long initTime =  System.currentTimeMillis();
			ArrayList<Integer> primes = dummy.primeList(i);
			long finalTime = System.currentTimeMillis();
			
			System.out.println(finalTime - initTime);
		}

	}

}
