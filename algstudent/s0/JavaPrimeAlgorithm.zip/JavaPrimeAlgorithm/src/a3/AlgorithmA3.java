package a3;

import java.util.ArrayList;

public class AlgorithmA3 {

	public AlgorithmA3() {
		
	}
	
	
	public boolean primeA3(int m) {
		
		for (int i = 2; i < m/2 + 1; i++) {
			if(m%i == 0) {
				return false;
			}
		}
		return true;
		
	}
	
	
	
	public ArrayList<Integer> primeList(int n) {
		ArrayList<Integer> primes = new ArrayList<Integer>();
		
		for (int i = 2; i <= n; i++) {
			if (primeA3(i)) {
				primes.add(i);
			}
		}
		
		return primes;
	}
	
}
