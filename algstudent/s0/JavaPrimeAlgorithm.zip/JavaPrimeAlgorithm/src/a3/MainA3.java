package a3;

import java.util.ArrayList;

public class MainA3 {

	public static void main(String[] args) {
		
		AlgorithmA3 dummy = new AlgorithmA3();
		
		
		for (int i = 10000; i <= 640000; i*=2) {
			long initTime =  System.currentTimeMillis();
			ArrayList<Integer> primes = dummy.primeList(i);
			long finalTime = System.currentTimeMillis();
			
			System.out.println(finalTime - initTime);
		}


	}

}
