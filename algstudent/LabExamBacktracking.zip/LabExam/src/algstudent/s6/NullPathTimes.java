package algstudent.s6;

public class NullPathTimes {
	
	private static int reps = 1;
	
	public static void main(String[] args) {
		long t1, t2;
		for (int i = 10; i < 11; i+=5) {
			t1 = System.currentTimeMillis();
			for (int rep = 0; rep < reps; rep++) {
				System.out.println("------------------------");
				System.out.println("Repetition: " + rep);
				NullPath.getNullPath(i);
			}
			t2 = System.currentTimeMillis();
			System.out.println("For graph of " + i + " nodes, it takes " + (t2-t1)/100.0 + " milliseconds");
		}
	}
}
